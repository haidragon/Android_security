package cn.ac.iie.rd6.everythingexported;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;

import java.security.MessageDigest;

public class FlagService extends Service {

    private String DESCRIPTOR = "FlagService" ;
    private MyBinder mBinder = new MyBinder();

    public FlagService() {
    }

    public String getFlag2( String username , String password){
        if( username.equals("admin") )
        {
            if ( Utils.MD5(password).equals("aaabf0d39951f3e6c3e8a7911df524c2") ){
                String flag2 = "flag{" + Utils.MD5(username + password) + "}";
                return flag2;
            }
        }
        return "failed to get flag2" ;
    }

    public void broadcastFlag3(String username , String password){
        if ( username.equals("admin") && Utils.MD5(password).equals("a2ae6cc9a7acfff494422585a43459c2")){
            Intent intent = new Intent("everything.exported.broadcast");
            String flag3 = "flag{" + Utils.MD5(username+password) + "}" ;
            intent.putExtra("flag3", flag3);
            sendBroadcast(intent);
        }else{
            // do nothing
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    public class MyBinder extends Binder{
        public FlagService getService(){ // this is useless in RPC mode
            return FlagService.this;
        }

        @Override
        protected boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            switch (code) {
                case 0x001: {
                    data.enforceInterface(DESCRIPTOR);
                    String username  = data.readString();
                    String password  = data.readString();

                    String flag2 = getFlag2(username , password);
                    reply.writeString(flag2);
                    return true;
                }

                case 0x002: {
                    data.enforceInterface(DESCRIPTOR);
                    String username  = data.readString();
                    String password  = data.readString();
                    broadcastFlag3(username, password) ;
                    return true;

                }
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }
}
