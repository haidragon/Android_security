package cn.ac.iie.rd6.everythingexported;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class FlagActivity extends AppCompatActivity {

    private String LOGTAG = "FlagActivity" ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flag);

        Intent intent = this.getIntent();
        if ( "export.everything.queryflag1".equals(intent.getAction())){
            try{
                String username = intent.getStringExtra("username");
                String password = intent.getStringExtra("password") ;
                if ( username.equals("admin") && Utils.MD5(password).equals("69a256025f66e4ce5d15c9dd7225d357")){
                    Intent result_intent = new Intent();
                    String flag1 = "flag{" + Utils.MD5(username + password) + "}" ;
                    result_intent.putExtra("flag1",flag1) ;
                    setResult(0, result_intent);
                    this.finish();
                }

            }catch(Exception e){
                e.printStackTrace();
            }
        }else{
            // do nothing
        }
    }
}
