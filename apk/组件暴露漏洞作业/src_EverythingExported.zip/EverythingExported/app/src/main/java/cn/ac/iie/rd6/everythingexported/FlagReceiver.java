package cn.ac.iie.rd6.everythingexported;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class FlagReceiver extends BroadcastReceiver {

    private String LOGTAG = "FlagReceiver" ;
    @Override
    public void onReceive(Context context, Intent intent) {
        if ( intent.getAction().equals("everything.exported.broadcast") ){
            Log.i(LOGTAG, "I received my flag");
        }
    }
}
