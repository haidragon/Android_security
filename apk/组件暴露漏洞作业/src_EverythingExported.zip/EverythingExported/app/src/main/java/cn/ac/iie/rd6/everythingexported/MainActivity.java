package cn.ac.iie.rd6.everythingexported;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private String LOG_TAG = "mainactivity" ;
    private TextView tv_output;


    public void initApplication(){
        tv_output = (TextView)findViewById(R.id.tv_output) ;
        tv_output.setText( getString(R.string.readme ));

        Button btn_activity = (Button)findViewById(R.id.btn_activity) ;
        Button btn_service = (Button)findViewById(R.id.btn_service) ;
        Button btn_broadcast = (Button)findViewById(R.id.btn_broadcast) ;
        Button btn_provider = (Button)findViewById(R.id.btn_provider) ;

        btn_activity.setOnClickListener(this);
        btn_service.setOnClickListener(this);
        btn_broadcast.setOnClickListener(this);
        btn_provider.setOnClickListener(this);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initApplication();
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.btn_activity:
                onActivity();
                break;
            case R.id.btn_broadcast:
                onBroadcast();
                break;
            case R.id.btn_provider:
                onProvider();
                break;
            case R.id.btn_service:
                onService();
                break;
        }
    }

    public void onActivity(){
        startActivity(new Intent(MainActivity.this, FlagActivity.class)) ;
    }

    public void onBroadcast(){
        tv_output.setText("not implemented");
    }

    public void onService(){
        tv_output.setText("not implemented");
    }

    public void onProvider(){
        tv_output.setText("not implemented");
    }

}
