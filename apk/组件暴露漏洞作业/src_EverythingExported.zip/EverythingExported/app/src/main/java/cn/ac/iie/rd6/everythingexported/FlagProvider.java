package cn.ac.iie.rd6.everythingexported;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import java.io.FileNotFoundException;

public class FlagProvider extends ContentProvider {

    private static UriMatcher mUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    private static final String AUTHORITY = "everything.exported.provider";
    private Utils.MyDBHelper mDbHelper;
    private SQLiteDatabase mDatabase;

    static {
        mUriMatcher.addURI(AUTHORITY, "download", 1 );  // type_all
        mUriMatcher.addURI(AUTHORITY, "download/#", 2 ); // TYPE_SINGLE
    }

    public FlagProvider() {
    }

    @Override
    public boolean onCreate() {
        mDbHelper = new Utils.MyDBHelper(getContext());
        mDatabase = mDbHelper.getWritableDatabase();
        String sql = "insert into download('filename', 'size') values('flag{e017d25452870cf49cb0e4ecf5b10aec}', 0)";
        mDatabase.execSQL(sql);
        return true;
    }

    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] columns, @Nullable String selection, @Nullable String[] selectionArgs, @Nullable String orderBy) {
        switch (mUriMatcher.match(uri)) {
            case 1:  // type all
                String sql = "select * from " + Utils.MyDBHelper.TABLE_NAME ;
                return mDatabase.query(Utils.MyDBHelper.TABLE_NAME, columns, selection, selectionArgs, null, null, orderBy);
            case 2:  // type single
                long id = ContentUris.parseId(uri);
                String where = Utils.MyDBHelper.COLUMN_ID + " = " + id;
                return mDatabase.query(Utils.MyDBHelper.TABLE_NAME, columns, where, selectionArgs, null, null, orderBy);
            default:
                return null;
        }
    }

    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues contentValues) {
        return null;
    }

    @Override
    public int delete(@NonNull Uri uri, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }

    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues contentValues, @Nullable String s, @Nullable String[] strings) {
        return 0;
    }
}
